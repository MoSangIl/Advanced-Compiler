
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/InstrTypes.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IRReader/IRReader.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/FileSystem.h"
#include "llvm/Support/raw_os_ostream.h"
#include "llvm/Support/raw_ostream.h"

#include "llvm/Analysis/LoopInfo.h"
#include "llvm/Analysis/OptimizationRemarkEmitter.h"
#include "llvm/IR/IRPrintingPasses.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Transforms/Scalar/LICM.h"

#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

std::string InputPath;
std::string OutputPath;
llvm::LLVMContext* TheContext;
std::unique_ptr<llvm::Module> TheModule;

llvm::raw_os_ostream rawcout(std::cout);

void run(void);

int main(int argc, char** argv) {
    if (argc < 3) {
	std::cout << "Usage: ./MoveInst <input_ir_file> <output_ir_file>"
		  << std::endl;
	return -1;
    }
    InputPath = std::string(argv[1]);
    OutputPath = std::string(argv[2]);

    // Run
    run();

    return 0;
}

void run(void) {
    llvm::SMDiagnostic err;

    // Context
    TheContext = new llvm::LLVMContext();
    if (!TheContext) {
	std::cerr << "Failed to allocated llvm::LLVMContext" << std::endl;
	exit(-1);
    }

    // Read & Parse IR File
    TheModule = llvm::parseIRFile(InputPath, err, *TheContext);
    if (!TheModule) {
	std::cerr << "Failed to parse IR File : " << InputPath << std::endl;
	exit(-1);
    }

    // Analysis Passes
    llvm::LoopAnalysisManager LAM;
    llvm::FunctionAnalysisManager FAM;
    llvm::ModuleAnalysisManager MAM;

    // Analysis Pass Building with Builder
    llvm::PassBuilder PB;
    llvm::CGSCCAnalysisManager CGAM;
    PB.registerModuleAnalyses(MAM);
    PB.registerCGSCCAnalyses(CGAM);
    PB.registerFunctionAnalyses(FAM);
    PB.registerLoopAnalyses(LAM);
    PB.crossRegisterProxies(LAM, FAM, CGAM, MAM);

    // Manual Analysis Pass Building
    FAM.registerPass([&] { return llvm::AAManager(); });
    FAM.registerPass([&] { return llvm::AssumptionAnalysis(); });
    FAM.registerPass([&] { return llvm::DominatorTreeAnalysis(); });
    FAM.registerPass([&] { return llvm::LoopAnalysis(); });
    FAM.registerPass([&] { return llvm::OptimizationRemarkEmitterAnalysis(); });
    FAM.registerPass([&] { return llvm::ScalarEvolutionAnalysis(); });
    FAM.registerPass([&] { return llvm::TargetLibraryAnalysis(); });
    FAM.registerPass([&] { return llvm::TargetIRAnalysis(); });

    MAM.registerPass(
	[&] { return llvm::FunctionAnalysisManagerModuleProxy(FAM); });
    FAM.registerPass(
	[&] { return llvm::ModuleAnalysisManagerFunctionProxy(MAM); });
    FAM.registerPass(
	[&] { return llvm::LoopAnalysisManagerFunctionProxy(LAM); });
    LAM.registerPass(
	[&] { return llvm::FunctionAnalysisManagerLoopProxy(FAM); });

    // Optimization Passes
    llvm::ModulePassManager MPM;
    llvm::FunctionPassManager FPM;
    llvm::LoopPassManager LPM;

    // Register Optimization Pass
    LPM.addPass(llvm::LICMPass());  // LICM
    FPM.addPass(
	llvm::RequireAnalysisPass<llvm::OptimizationRemarkEmitterAnalysis,
				  llvm::Function>());  // Required for LICM
    FPM.addPass(llvm::createFunctionToLoopPassAdaptor(std::move(LPM)));
    MPM.addPass(llvm::createModuleToFunctionPassAdaptor(std::move(FPM)));

    std::error_code EC;
    llvm::raw_fd_ostream raw_output(OutputPath, EC,
				    llvm::sys::fs::OpenFlags::F_None);
    MPM.addPass(llvm::PrintModulePass(raw_output));  // Print Module

    // Run
    MPM.run(*TheModule.get(), MAM);
}
