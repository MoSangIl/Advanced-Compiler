#include <stdio.h>

// External Linkage Variable e for Preventing Constant Folding
extern int e;

int main(void) {
	int a = 3;
	int b = 4;
	int c = 5;
	int d = 6;

	// LICM Hoisting Example
	for (int i = 0; i < 1000000000; ++i) {
		a = (e % 20220509 + 37124) % 2778 * (e % 90502202 + 379);  // Loop Invarient Code
		b += e * i - b;
	}

	// LICM Sinking Example
	int i = 0;
	do {
		c = (e % 20220509 + 37124) % 2778 * (e % 90502202 + 379);  // Loop Invarient Code
		d += e * i - d;
		++i;
	} while (i < 1000000000);

	// Use Variable a, b, c, d for Preventing DCE
	printf("a = %d, b = %d, c = %d, d = %d\n", a, b, c, d);

	return 0;
}
